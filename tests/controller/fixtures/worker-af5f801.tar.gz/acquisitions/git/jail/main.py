"""The process side of the supported Git command interface: the `git` shim
(git.py) runs it. The real Git for local pass-through is the fixed
/usr/bin/git, with this process's own standard streams, environment and
working directory: it is the guest's ordinary local Git, not intercepted and
not a security claim. SIGINT, SIGTERM or SIGHUP cancel a clone or fetch
request (bytes already applied stay); a local Git gets terminal signals
itself and is awaited."""

import asyncio
import os
import sys

from acquisitions.git.jail.dispatch import run_git_command
from guest.src.abort import signalled
from guest.src.artifact_post_context import context_from_environment

# The fixed real Git; never looked up on PATH, which may hold the wrapper.
REAL_GIT = "/usr/bin/git"


async def pass_through(args):
    """The real Git with exactly `args`; its status, 128 + the signal's number when killed."""
    try:
        child = await asyncio.create_subprocess_exec(REAL_GIT, *args)
    except OSError:
        return 127
    code = await child.wait()
    return 128 - code if code < 0 else code


async def git_main(args):
    """One Git command with the request context of this process's
    environment, read once; awaited to its end, the handlers stay until it
    settled."""
    abort, done = signalled(asyncio.get_running_loop())

    def report(line):
        sys.stderr.write(line + "\n")
        sys.stderr.flush()

    try:
        return await run_git_command(list(args), os.getcwd(), context_from_environment(os.environ), report,
                                     pass_through, abort)
    finally:
        done()
